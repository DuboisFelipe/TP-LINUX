#!/bin/bash
# Fecha actual en formato YYYYMMDD
FECHA=$(date +%Y%m%d)

# Mostrar ayuda
if [[ "$1" == "-help" ]]; then
  echo "Uso: $0 ORIGEN DESTINO"
  echo "Ejemplo: $0 /var/log /backup_dir"
  exit 0
fi

# Validar argumentos
if [[ -z "$1" || -z "$2" ]]; then
  echo "Error: Debe especificar directorio origen y destino."
  echo "Use -help para más información."
  exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validar que los directorios existen
if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: El directorio de origen '$ORIGEN' no existe."
  exit 1
fi

if [[ ! -d "$DESTINO" ]]; then
  echo "Error: El directorio de destino '$DESTINO' no existe."
  exit 1
fi

# Obtener nombre del backup según origen
NOMBRE=$(basename "$ORIGEN" | tr -d '/')
ARCHIVO="${DESTINO}/${NOMBRE}_bkp_${FECHA}.tar.gz"

# Crear backup
tar -czf "$ARCHIVO" "$ORIGEN"

# Verificar si se creó correctamente
if [[ $? -eq 0 ]]; then
  echo "Backup creado exitosamente: $ARCHIVO"
else
  echo "Error al crear el backup."
  exit 1
fi
